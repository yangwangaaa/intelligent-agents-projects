package AgentMouche;

public class Configuration {

	private int id ;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Configuration(int id) {
		super();
		this.id = id;
	}
}
